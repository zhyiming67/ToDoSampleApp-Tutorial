//
//  Main file including Amplify configuration
//  AmplifyConfigTemplate
//
//  Created by AWS Amplify.
//
import Amplify
import AWSDataStorePlugin
import AWSAPIPlugin
import SwiftUI

@main
struct ___VARIABLE_productName:identifier___: App {
    public init() {
           configureAmplify()
       }
    
    var body: some Scene {
        WindowGroup {

        }
    }
}

///Configure Amplify
func configureAmplify() {
    let models = AmplifyModels()
//    let apiPlugin = AWSAPIPlugin(modelRegistration: models)
    let dataStorePlugin = AWSDataStorePlugin(modelRegistration: models)
    do {
//        try Amplify.add(plugin: apiPlugin)
        try Amplify.add(plugin: dataStorePlugin)
        try Amplify.configure()
        print("Initialized Amplify");
    } catch {
        assert(false, "Could not initialize Amplify: \(error)")
    }
}
