import Amplify
import Foundation

/// Create a new item or update an existing item. DataStore uses id to decide.
/// - Parameter Item: An item to be created which must follows the schema.graphql.
public func create<T: Model>(item: T) {
    Amplify.DataStore.save(item) { result in
               switch(result) {
               case .success(let savedItem):
                print("Saved item: \(savedItem.self)")
               case .failure(let error):
                   print("Could not save item to DataStore: \(error)")
               }
            }
}

/// Query one item according to the query parameter in DataStore and return it
/// - Parameters:
///   - type: Any item following the schema.graphql
///   - queryConditon: Query parameter. For example, ToDoItem.keys.id.eq(toDoItem.id)
/// - Returns: An optional item
public func query<T: Model>(type: T, queryConditon: QueryPredicate?) -> T? {
    var item: T? = nil
    /// And we delete Todo using id equal. 'Where' is the query parameter, here is to query the item with the same id of item.
    Amplify.DataStore.query(T.self, where: queryConditon) { result in
        switch(result) {
        case .success(let outputs):
            guard outputs.count == 1, let output = outputs.first else {
                print("Did not find exactly one todo, bailing")
                return
            }
            item = output
        case .failure(let error):
            print("Could not query DataStore: \(error)")
        }
    }
    return item
}

/// Query all items in DataStore and return them
/// - Parameter type: Any item following the schema.graphql
/// - Returns: Array of items
public func queryAll<T: Model>(type: T) -> [T] {
    var items: [T] = []
    Amplify.DataStore.query(T.self) { result in
           switch(result) {
           case .success(let todos):
               items = todos
           case .failure(let error):
               print("Could not query DataStore: \(error)")
           }
       }
    return items
}

/// Delete an item
/// - Parameter Item: An item to be created which must follows the schema.graphql.
public func delete<T: Model>(item: T) {
    Amplify.DataStore.delete(item) { result in
        switch(result) {
        case .success:
            print("Deleted item: \(item.self)")
        case .failure(let error):
            print("Could not delete data in DataStore: \(error)")
        }
    }
}
